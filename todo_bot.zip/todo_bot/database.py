# database.py — SQLite bilan ishlash

import aiosqlite
import json
import os
from config import DB_PATH, DEFAULT_LANG

# ─── Locale yuklash ───────────────────────────────────────────────────────────

_locales: dict[str, dict] = {}


def _load_locales():
    base = os.path.join(os.path.dirname(__file__), "locales")
    for lang in ("uz", "ru", "en"):
        path = os.path.join(base, f"{lang}.json")
        with open(path, encoding="utf-8") as f:
            _locales[lang] = json.load(f)


_load_locales()


def t(key: str, lang: str = DEFAULT_LANG, **kwargs) -> str:
    """Tarjima matni qaytaradi."""
    locale = _locales.get(lang, _locales[DEFAULT_LANG])
    text = locale.get(key, _locales[DEFAULT_LANG].get(key, key))
    if kwargs:
        text = text.format(**kwargs)
    return text


# ─── DB Inicializatsiya ───────────────────────────────────────────────────────

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id   INTEGER PRIMARY KEY,
                username  TEXT,
                full_name TEXT,
                lang      TEXT DEFAULT 'uz',
                is_active INTEGER DEFAULT 1,
                joined_at TEXT DEFAULT (datetime('now'))
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER NOT NULL,
                text       TEXT NOT NULL,
                status     TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT (datetime('now')),
                done_at    TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        await db.commit()


# ─── Foydalanuvchi operatsiyalari ────────────────────────────────────────────

async def register_user(user_id: int, username: str | None, full_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO users (user_id, username, full_name, is_active)
            VALUES (?, ?, ?, 1)
            ON CONFLICT(user_id) DO UPDATE SET
                username  = excluded.username,
                full_name = excluded.full_name,
                is_active = 1
        """, (user_id, username, full_name))
        await db.commit()


async def mark_user_left(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET is_active=0 WHERE user_id=?", (user_id,)
        )
        await db.commit()


async def get_user_lang(user_id: int) -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT lang FROM users WHERE user_id=?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
            return row[0] if row else DEFAULT_LANG


async def set_user_lang(user_id: int, lang: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET lang=? WHERE user_id=?", (lang, user_id)
        )
        await db.commit()


async def get_all_active_users() -> list[int]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT user_id FROM users WHERE is_active=1"
        ) as cur:
            rows = await cur.fetchall()
            return [r[0] for r in rows]


# ─── Vazifa operatsiyalari ────────────────────────────────────────────────────

async def add_task(user_id: int, text: str) -> int:
    """Yangi vazifa qo'shadi, task_id qaytaradi."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "INSERT INTO tasks (user_id, text) VALUES (?, ?)",
            (user_id, text)
        ) as cur:
            task_id = cur.lastrowid
        await db.commit()
        return task_id


async def get_pending_tasks(user_id: int) -> list[dict]:
    """Foydalanuvchining kutilayotgan vazifalari."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("""
            SELECT id, text, created_at FROM tasks
            WHERE user_id=? AND status='pending'
            ORDER BY created_at ASC
        """, (user_id,)) as cur:
            rows = await cur.fetchall()
            return [{"id": r[0], "text": r[1], "created_at": r[2]} for r in rows]


async def get_done_tasks(user_id: int) -> list[dict]:
    """Foydalanuvchining bajarilgan vazifalari."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("""
            SELECT id, text, done_at FROM tasks
            WHERE user_id=? AND status='done'
            ORDER BY done_at DESC
        """, (user_id,)) as cur:
            rows = await cur.fetchall()
            return [{"id": r[0], "text": r[1], "done_at": r[2]} for r in rows]


async def mark_task_done(task_id: int, user_id: int) -> str:
    """
    'done'   — muvaffaqiyatli belgilandi
    'already' — allaqachon bajarilgan
    'not_found' — topilmadi
    """
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT status FROM tasks WHERE id=? AND user_id=?",
            (task_id, user_id)
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return "not_found"
        if row[0] == "done":
            return "already"
        await db.execute("""
            UPDATE tasks SET status='done', done_at=datetime('now')
            WHERE id=? AND user_id=?
        """, (task_id, user_id))
        await db.commit()
        return "done"


async def delete_task(task_id: int, user_id: int) -> bool:
    """True qaytaradi agar o'chirilsa."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT 1 FROM tasks WHERE id=? AND user_id=?",
            (task_id, user_id)
        ) as cur:
            if not await cur.fetchone():
                return False
        await db.execute(
            "DELETE FROM tasks WHERE id=? AND user_id=?",
            (task_id, user_id)
        )
        await db.commit()
        return True


async def clear_all_tasks(user_id: int):
    """Foydalanuvchining barcha vazifalarini o'chiradi."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM tasks WHERE user_id=?", (user_id,)
        )
        await db.commit()


# ─── Statistika ───────────────────────────────────────────────────────────────

async def get_stats() -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM users") as cur:
            total_users = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM tasks") as cur:
            total_tasks = (await cur.fetchone())[0]
        async with db.execute(
            "SELECT COUNT(*) FROM tasks WHERE status='done'"
        ) as cur:
            done_tasks = (await cur.fetchone())[0]
    return {
        "total_users": total_users,
        "total_tasks": total_tasks,
        "done_tasks": done_tasks,
    }
