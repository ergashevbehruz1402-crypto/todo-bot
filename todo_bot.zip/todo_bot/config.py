# config.py — Bot sozlamalari

BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"  # @BotFather dan olingan token

ADMIN_ID = 123456789  # Sizning Telegram ID raqamingiz

DB_PATH = "todo_bot.db"  # SQLite ma'lumotlar bazasi fayli

DEFAULT_LANG = "uz"  # Standart til
