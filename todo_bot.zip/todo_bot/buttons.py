# buttons.py — Barcha klaviaturalar

from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from database import t


# ─── ReplyKeyboard: Foydalanuvchi ────────────────────────────────────────────

def user_keyboard(lang: str = "uz") -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=t("btn_add_task", lang))],
            [
                KeyboardButton(text=t("btn_my_tasks", lang)),
                KeyboardButton(text=t("btn_done_tasks", lang)),
            ],
            [KeyboardButton(text=t("btn_clear_all", lang))],
        ],
        resize_keyboard=True,
        persistent=True,
    )


# ─── ReplyKeyboard: Admin ─────────────────────────────────────────────────────

def admin_keyboard(lang: str = "uz") -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text=t("btn_stats", lang)),
                KeyboardButton(text=t("btn_send_ad", lang)),
            ],
            [KeyboardButton(text=t("btn_cancel", lang))],
        ],
        resize_keyboard=True,
        persistent=True,
    )


# ─── ReplyKeyboard: Bekor qilish ─────────────────────────────────────────────

def cancel_keyboard(lang: str = "uz") -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=t("btn_cancel", lang))]],
        resize_keyboard=True,
    )


# ─── InlineKeyboard: Vazifa tugmalari ────────────────────────────────────────

def task_keyboard(task_id: int, lang: str = "uz") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text=t("btn_task_done", lang),
            callback_data=f"task:done:{task_id}"
        ),
        InlineKeyboardButton(
            text=t("btn_task_delete", lang),
            callback_data=f"task:delete:{task_id}"
        ),
    ]])


# ─── InlineKeyboard: Hammasini tozalash tasdiqlash ───────────────────────────

def clear_confirm_keyboard(lang: str = "uz") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text=t("btn_yes", lang),
            callback_data="clear:yes"
        ),
        InlineKeyboardButton(
            text=t("btn_no", lang),
            callback_data="clear:no"
        ),
    ]])


# ─── InlineKeyboard: Til tanlash ─────────────────────────────────────────────

def language_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🇺🇿 O'zbek", callback_data="lang:uz"),
        InlineKeyboardButton(text="🇷🇺 Русский", callback_data="lang:ru"),
        InlineKeyboardButton(text="🇬🇧 English", callback_data="lang:en"),
    ]])


# ─── InlineKeyboard: Reklama tasdiqlash ──────────────────────────────────────

def ad_confirm_keyboard(lang: str = "uz") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text=t("ad_confirm_btn", lang),
            callback_data="ad:confirm"
        ),
        InlineKeyboardButton(
            text=t("ad_cancel_btn", lang),
            callback_data="ad:cancel"
        ),
    ]])


# ─── InlineKeyboard: Yordam (admin havolasi) ─────────────────────────────────

def help_keyboard(admin_username: str | None, lang: str = "uz") -> InlineKeyboardMarkup:
    url = f"https://t.me/{admin_username}" if admin_username else "https://t.me/"
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=t("help_btn", lang), url=url)
    ]])


# ─── Yordamchi: barcha tillardagi tugma matnlari ─────────────────────────────

def all_btn_texts(key: str) -> set[str]:
    return {t(key, lang) for lang in ("uz", "ru", "en")}
