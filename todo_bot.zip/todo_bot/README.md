# ✅ TODO Bot

Aiogram 3.x asosida yozilgan Telegram vazifalar (TODO) boti.

---

## 📁 Fayl tuzilmasi

```
todo_bot/
├── main.py          — Handler'lar, FSM, dispatcher
├── buttons.py       — Barcha klaviaturalar
├── database.py      — SQLite: vazifalar, foydalanuvchilar
├── config.py        — BOT_TOKEN, ADMIN_ID
├── requirements.txt — Kutubxonalar
└── locales/
    ├── uz.json      — O'zbek tili
    ├── ru.json      — Rus tili
    └── en.json      — Ingliz tili
```

---

## ⚙️ O'rnatish

### 1. Kutubxonalarni o'rnating
```bash
pip install -r requirements.txt
```

### 2. `config.py` ni to'ldiring
```python
BOT_TOKEN = "YOUR_BOT_TOKEN"   # @BotFather
ADMIN_ID  = 123456789           # Sizning Telegram ID
```

> **ID ni qanday bilish:** @userinfobot yoki @getmyid_bot ga yozing.

### 3. Ishga tushiring
```bash
python main.py
```

---

## 🎯 Funksiyalar

### Foydalanuvchi uchun
| Tugma / Komanda | Vazifa |
|---|---|
| `➕ Vazifa qo'shish` / `/qosh` | Yangi vazifa qo'shish |
| `📋 Vazifalarim` / `/vazifalar` | Kutilayotgan vazifalar (✅ Bajarildi + 🗑️ O'chirish) |
| `✅ Bajarilganlar` / `/bajarilgan` | Bajarilgan vazifalar ro'yxati |
| `🧹 Hammasini tozalash` | Barcha vazifalarni o'chirish (tasdiqlash bilan) |
| `/language` | Til tanlash 🇺🇿 🇷🇺 🇬🇧 |
| `/help` | Admin havolasi |

### Admin uchun
| Tugma | Vazifa |
|---|---|
| `📊 Statistika` | Foydalanuvchilar, vazifalar, bajarilganlar soni |
| `📢 Reklama yuborish` | Matn/rasm/video — preview + tasdiqlash |

---

## 🗄️ Ma'lumotlar bazasi

**users jadvali** — foydalanuvchilar, til, faollik holati

**tasks jadvali** — vazifa matni, holati (`pending` / `done`), sanalar

Har bir foydalanuvchi faqat o'z vazifalarini ko'radi (**to'liq izolyatsiya**).

---

## 🌐 Til tizimi

`/language` orqali til tanlanadi va SQLite'da saqlanadi.
Barcha xabarlar, tugmalar va bildirishnomalar tanlangan tilda chiqadi.
