# main.py — Asosiy handler'lar va FSM state'lar

import asyncio
import logging
import html

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    ChatMemberUpdated,
    Message,
    ReplyKeyboardRemove,
)
from aiogram.filters import ChatMemberUpdatedFilter, IS_MEMBER, IS_NOT_MEMBER

import database as db
from buttons import (
    admin_keyboard,
    ad_confirm_keyboard,
    all_btn_texts,
    cancel_keyboard,
    clear_confirm_keyboard,
    help_keyboard,
    language_keyboard,
    task_keyboard,
    user_keyboard,
)
from config import ADMIN_ID, BOT_TOKEN
from database import t

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

router = Router()


# ══════════════════════════════════════════════════════════════════════════════
# FSM State'lar
# ══════════════════════════════════════════════════════════════════════════════

class AddTask(StatesGroup):
    waiting_text = State()


class SendAd(StatesGroup):
    waiting_message = State()
    waiting_confirm = State()


# ══════════════════════════════════════════════════════════════════════════════
# Yordamchi funksiyalar
# ══════════════════════════════════════════════════════════════════════════════

def is_admin(user_id: int) -> bool:
    return user_id == ADMIN_ID


async def get_lang(user_id: int) -> str:
    return await db.get_user_lang(user_id)


async def send_main_menu(message: Message, lang: str):
    uid = message.from_user.id if message.from_user else 0
    if is_admin(uid):
        kb = admin_keyboard(lang)
    else:
        kb = user_keyboard(lang)
    await message.answer("👇", reply_markup=kb)


# ══════════════════════════════════════════════════════════════════════════════
# /start
# ══════════════════════════════════════════════════════════════════════════════

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    user = message.from_user
    await db.register_user(user.id, user.username, user.full_name)
    lang = await get_lang(user.id)
    name = html.escape(user.full_name or user.username or "Foydalanuvchi")

    if is_admin(user.id):
        text = t("welcome_admin", lang, name=name)
        kb = admin_keyboard(lang)
    else:
        text = t("welcome_user", lang, name=name)
        kb = user_keyboard(lang)

    await message.answer(text, reply_markup=kb)


# ══════════════════════════════════════════════════════════════════════════════
# /language
# ══════════════════════════════════════════════════════════════════════════════

@router.message(Command("language"))
async def cmd_language(message: Message, state: FSMContext):
    await state.clear()
    lang = await get_lang(message.from_user.id)
    await message.answer(t("language_select", lang), reply_markup=language_keyboard())


@router.callback_query(F.data.startswith("lang:"))
async def cb_language(callback: CallbackQuery, state: FSMContext):
    new_lang = callback.data.split(":")[1]
    uid = callback.from_user.id
    await db.set_user_lang(uid, new_lang)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer(t("language_changed", new_lang))
    await callback.message.answer(t("language_changed", new_lang))
    await send_main_menu(callback.message, new_lang)


# ══════════════════════════════════════════════════════════════════════════════
# /help
# ══════════════════════════════════════════════════════════════════════════════

@router.message(Command("help"))
async def cmd_help(message: Message, bot: Bot):
    lang = await get_lang(message.from_user.id)
    try:
        admin = await bot.get_chat(ADMIN_ID)
        admin_username = getattr(admin, "username", None)
    except Exception:
        admin_username = None
    await message.answer(
        t("help_text", lang),
        reply_markup=help_keyboard(admin_username, lang),
    )


# ══════════════════════════════════════════════════════════════════════════════
# Bekor qilish (universal)
# ══════════════════════════════════════════════════════════════════════════════

@router.message(F.text.func(lambda txt: txt in all_btn_texts("btn_cancel")))
async def handle_cancel(message: Message, state: FSMContext):
    current = await state.get_state()
    lang = await get_lang(message.from_user.id)
    await state.clear()
    if current:
        await message.answer(t("cancel", lang))
    await send_main_menu(message, lang)


# ══════════════════════════════════════════════════════════════════════════════
# /qosh — Vazifa qo'shish
# ══════════════════════════════════════════════════════════════════════════════

@router.message(Command("qosh"))
async def cmd_qosh(message: Message, state: FSMContext):
    lang = await get_lang(message.from_user.id)
    await state.set_state(AddTask.waiting_text)
    await message.answer(t("enter_task", lang), reply_markup=cancel_keyboard(lang))


@router.message(F.text.func(lambda txt: txt in all_btn_texts("btn_add_task")))
async def handle_add_task_btn(message: Message, state: FSMContext):
    lang = await get_lang(message.from_user.id)
    await state.set_state(AddTask.waiting_text)
    await message.answer(t("enter_task", lang), reply_markup=cancel_keyboard(lang))


@router.message(AddTask.waiting_text)
async def handle_task_text(message: Message, state: FSMContext):
    lang = await get_lang(message.from_user.id)
    text = (message.text or "").strip()
    if not text:
        await message.answer(t("invalid_input", lang))
        return

    await db.add_task(message.from_user.id, text)
    await state.clear()

    escaped = html.escape(text)
    await message.answer(t("task_added", lang, text=escaped))
    await send_main_menu(message, lang)


# ══════════════════════════════════════════════════════════════════════════════
# /vazifalar — Barcha vazifalar
# ══════════════════════════════════════════════════════════════════════════════

async def show_pending_tasks(message: Message, uid: int, lang: str):
    tasks = await db.get_pending_tasks(uid)
    if not tasks:
        await message.answer(t("no_tasks", lang))
        return

    await message.answer(t("tasks_header", lang))
    for task in tasks:
        escaped = html.escape(task["text"])
        task_text = f"{t('task_status_pending', lang)} <b>{escaped}</b>"
        await message.answer(task_text, reply_markup=task_keyboard(task["id"], lang))


@router.message(Command("vazifalar"))
async def cmd_vazifalar(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    lang = await get_lang(uid)
    await show_pending_tasks(message, uid, lang)


@router.message(F.text.func(lambda txt: txt in all_btn_texts("btn_my_tasks")))
async def handle_my_tasks_btn(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    lang = await get_lang(uid)
    await show_pending_tasks(message, uid, lang)


# ══════════════════════════════════════════════════════════════════════════════
# /bajarilgan — Bajarilgan vazifalar
# ══════════════════════════════════════════════════════════════════════════════

async def show_done_tasks(message: Message, uid: int, lang: str):
    tasks = await db.get_done_tasks(uid)
    if not tasks:
        await message.answer(t("no_done_tasks", lang))
        return

    await message.answer(t("done_tasks_header", lang))
    for task in tasks:
        escaped = html.escape(task["text"])
        task_text = f"{t('task_status_done', lang)} <b>{escaped}</b>"
        # Bajarilgan vazifalarda faqat o'chirish tugmasi
        kb = __import__("aiogram.types", fromlist=["InlineKeyboardMarkup"]).InlineKeyboardMarkup(
            inline_keyboard=[[
                __import__("aiogram.types", fromlist=["InlineKeyboardButton"]).InlineKeyboardButton(
                    text=t("btn_task_delete", lang),
                    callback_data=f"task:delete:{task['id']}"
                )
            ]]
        )
        await message.answer(task_text, reply_markup=kb)


@router.message(Command("bajarilgan"))
async def cmd_bajarilgan(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    lang = await get_lang(uid)
    await show_done_tasks(message, uid, lang)


@router.message(F.text.func(lambda txt: txt in all_btn_texts("btn_done_tasks")))
async def handle_done_tasks_btn(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    lang = await get_lang(uid)
    await show_done_tasks(message, uid, lang)


# ══════════════════════════════════════════════════════════════════════════════
# InlineKeyboard: Vazifa — Bajarildi / O'chirish
# ══════════════════════════════════════════════════════════════════════════════

@router.callback_query(F.data.startswith("task:done:"))
async def cb_task_done(callback: CallbackQuery):
    uid = callback.from_user.id
    lang = await get_lang(uid)
    task_id = int(callback.data.split(":")[2])

    result = await db.mark_task_done(task_id, uid)

    if result == "done":
        await callback.answer(t("task_done", lang), show_alert=False)
        # Xabar matnini yangilaymiz, tugmani olib tashlaymiz
        original = callback.message.text or ""
        # Statusni yangilaymiz: ⏳ → ✅
        new_text = original.replace(
            t("task_status_pending", lang),
            t("task_status_done", lang),
            1
        )
        # Faqat o'chirish tugmasi qoladi
        from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(
                text=t("btn_task_delete", lang),
                callback_data=f"task:delete:{task_id}"
            )
        ]])
        try:
            await callback.message.edit_text(new_text, reply_markup=kb)
        except Exception:
            await callback.message.edit_reply_markup(reply_markup=kb)
    elif result == "already":
        await callback.answer(t("task_already_done", lang), show_alert=True)
    else:
        await callback.answer(t("task_not_found", lang), show_alert=True)


@router.callback_query(F.data.startswith("task:delete:"))
async def cb_task_delete(callback: CallbackQuery):
    uid = callback.from_user.id
    lang = await get_lang(uid)
    task_id = int(callback.data.split(":")[2])

    deleted = await db.delete_task(task_id, uid)
    if deleted:
        await callback.answer(t("task_deleted", lang), show_alert=False)
        await callback.message.delete()
    else:
        await callback.answer(t("task_not_found", lang), show_alert=True)


# ══════════════════════════════════════════════════════════════════════════════
# Hammasini tozalash
# ══════════════════════════════════════════════════════════════════════════════

@router.message(F.text.func(lambda txt: txt in all_btn_texts("btn_clear_all")))
async def handle_clear_all_btn(message: Message, state: FSMContext):
    lang = await get_lang(message.from_user.id)
    await message.answer(
        t("confirm_clear", lang),
        reply_markup=clear_confirm_keyboard(lang)
    )


@router.callback_query(F.data == "clear:yes")
async def cb_clear_yes(callback: CallbackQuery):
    uid = callback.from_user.id
    lang = await get_lang(uid)
    await db.clear_all_tasks(uid)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer()
    await callback.message.answer(t("all_cleared", lang))


@router.callback_query(F.data == "clear:no")
async def cb_clear_no(callback: CallbackQuery):
    lang = await get_lang(callback.from_user.id)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer()
    await callback.message.answer(t("clear_cancelled", lang))


# ══════════════════════════════════════════════════════════════════════════════
# ADMIN: Statistika
# ══════════════════════════════════════════════════════════════════════════════

@router.message(F.text.func(lambda txt: txt in all_btn_texts("btn_stats")))
async def handle_stats_btn(message: Message):
    uid = message.from_user.id
    lang = await get_lang(uid)
    if not is_admin(uid):
        await message.answer(t("no_permission", lang))
        return

    stats = await db.get_stats()
    lines = [
        t("stats_header", lang),
        t("stats_users", lang, count=stats["total_users"]),
        t("stats_tasks", lang, count=stats["total_tasks"]),
        t("stats_done", lang, count=stats["done_tasks"]),
    ]
    await message.answer("\n".join(lines))


# ══════════════════════════════════════════════════════════════════════════════
# ADMIN: Reklama yuborish
# ══════════════════════════════════════════════════════════════════════════════

@router.message(F.text.func(lambda txt: txt in all_btn_texts("btn_send_ad")))
async def handle_send_ad_btn(message: Message, state: FSMContext):
    uid = message.from_user.id
    lang = await get_lang(uid)
    if not is_admin(uid):
        await message.answer(t("no_permission", lang))
        return
    await state.set_state(SendAd.waiting_message)
    await message.answer(t("send_ad_prompt", lang), reply_markup=cancel_keyboard(lang))


@router.message(SendAd.waiting_message)
async def handle_ad_message(message: Message, state: FSMContext):
    lang = await get_lang(message.from_user.id)

    if message.text:
        ad_type, ad_content, ad_caption = "text", message.text, None
    elif message.photo:
        ad_type, ad_content, ad_caption = "photo", message.photo[-1].file_id, message.caption
    elif message.video:
        ad_type, ad_content, ad_caption = "video", message.video.file_id, message.caption
    else:
        await message.answer(t("invalid_input", lang))
        return

    await state.update_data(ad_type=ad_type, ad_content=ad_content, ad_caption=ad_caption)
    await state.set_state(SendAd.waiting_confirm)

    # Preview
    await message.answer(t("ad_confirm", lang), reply_markup=ReplyKeyboardRemove())
    await message.forward(chat_id=message.chat.id)
    await message.answer("👆", reply_markup=ad_confirm_keyboard(lang))


@router.callback_query(F.data == "ad:confirm", SendAd.waiting_confirm)
async def cb_ad_confirm(callback: CallbackQuery, state: FSMContext, bot: Bot):
    lang = await get_lang(callback.from_user.id)
    data = await state.get_data()
    await state.clear()
    await callback.message.edit_reply_markup(reply_markup=None)

    users = await db.get_all_active_users()
    count = 0

    for uid in users:
        try:
            if data["ad_type"] == "text":
                await bot.send_message(uid, data["ad_content"])
            elif data["ad_type"] == "photo":
                await bot.send_photo(uid, data["ad_content"], caption=data.get("ad_caption"))
            elif data["ad_type"] == "video":
                await bot.send_video(uid, data["ad_content"], caption=data.get("ad_caption"))
            count += 1
        except Exception as e:
            logger.warning(f"[AD] {uid} ga yuborib bo'lmadi: {e}")
            err = str(e).lower()
            if "blocked" in err or "deactivated" in err or "not found" in err:
                await db.mark_user_left(uid)

    await callback.answer()
    await callback.message.answer(t("ad_sent", lang, count=count))
    await send_main_menu(callback.message, lang)


@router.callback_query(F.data == "ad:cancel", SendAd.waiting_confirm)
async def cb_ad_cancel(callback: CallbackQuery, state: FSMContext):
    lang = await get_lang(callback.from_user.id)
    await state.clear()
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer()
    await callback.message.answer(t("ad_cancelled", lang))
    await send_main_menu(callback.message, lang)


# ══════════════════════════════════════════════════════════════════════════════
# Bot blocked / unblocked
# ══════════════════════════════════════════════════════════════════════════════

@router.my_chat_member(ChatMemberUpdatedFilter(IS_MEMBER >> IS_NOT_MEMBER))
async def user_blocked_bot(event: ChatMemberUpdated):
    await db.mark_user_left(event.from_user.id)
    logger.info(f"[BLOCK] {event.from_user.id} botni blokladi.")


@router.my_chat_member(ChatMemberUpdatedFilter(IS_NOT_MEMBER >> IS_MEMBER))
async def user_unblocked_bot(event: ChatMemberUpdated):
    u = event.from_user
    await db.register_user(u.id, u.username, u.full_name)
    logger.info(f"[UNBLOCK] {u.id} botni qayta yoqdi.")


# ══════════════════════════════════════════════════════════════════════════════
# Ishga tushirish
# ══════════════════════════════════════════════════════════════════════════════

async def main():
    await db.init_db()

    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    logger.info("✅ TODO Bot ishga tushmoqda...")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
